# Operation SILENT LANTERN — standalone project

This project contains only the SILENT LANTERN UFED-only classroom activity,
its backend, and its database schema. It does not depend on IRON MERIDIAN.
The website runs at `/`, with its own instructor console at `/instructor`.

## Create the separate Replit project

1. Go to https://replit.com/import and select **ZIP**.
2. Upload this archive and name the new project **SILENT LANTERN CTF**.
3. In the new project, use Replit's Database tool to provision/configure a
   **new PostgreSQL database**. Do not point it at the IRON MERIDIAN database.
   Replit supplies `DATABASE_URL`; no connection value is included here.
4. Add `CTF_INSTRUCTOR_CODE` in the new project's **Secrets** tool.
   No secret values have been copied from the original project.
5. Click **Run**. Dependencies install, development tables are created,
   and the website builds and starts on one port.
6. In **Instructor**, configure the iPhone Major match, courier alias, and final
   watchlist keyword. Enter only the keyword for the final TPL key. Review each
   learner's SIM IMSI individually. No preserved extraction or AUTH token is required.

Learner records, instructor dataset keys and existing resume sessions are
NOT included. The new project starts with a fresh database. The original
projects and their saved records have not been deleted or changed.

## Features

- Six UFED-only missions, 26 responses, 165 base points
- Names, team numbers, learner email and instructor email
- Saved responses and private resume links
- Self-validation, strict flag formats and server-enforced mission unlocks
- Three hint tokens, each deducting two points
- Knowledge-based Preserved/SafeGuard questions, iPhone Triage before targeted
  collection, individual SIM review, and UFED Classic ZTE Mission 5
- Read-only archived responses from the earlier curriculum; original records are retained
- Written-answer review, optional speed and tradecraft bonuses
- Instructor-only searchable answer guide with sample responses and print view
- Protected per-question history of written submissions and instructor decisions
- Downloadable results and provider-free email drafts

Email opens the learner's mail app. It does not send automatically.

## Commands

- `pnpm install --frozen-lockfile`
- `pnpm run dev` — initialize development schema, build and start
- `pnpm run build` — typecheck and build both parts
- `pnpm run start` — run the built website and API
- `pnpm run codegen` — regenerate clients and validators after API changes
- `pnpm run db:push` — apply the schema to the configured development database
- `pnpm run db:migrate-history` — additive history migration; retains existing
  latest responses as imported snapshots without inventing lost attempts or review times

Production runs the built application; it does not run database schema
changes at startup. Configure the new project's production database and
schema through Replit's publishing/database setup before using it live.

## Source of truth

Use the feedback workbook and feedback DOCX in `resources/` as the latest
curriculum changes; they supersede the older question order, preserved-device
requirement, SIM assumptions, and Mission 5 in the original packets.
The canonical structure remains six missions. Do not add PA/Streamline workflows
or the conflicting eight-phase narrative as additional graded missions.
