import { Router, type IRouter } from "express";
import healthRouter from "./health";
import lanternRouter from "./lantern";
const router: IRouter = Router();
router.use(healthRouter);
router.use(lanternRouter);
export default router;
