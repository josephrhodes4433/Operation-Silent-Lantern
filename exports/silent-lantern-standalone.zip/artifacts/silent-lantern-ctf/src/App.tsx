import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { WindowGate } from '@/components/window-gate';
import NotFound from '@/pages/not-found';
import Overview from '@/pages/overview';
import Activity from '@/pages/activity';
import Results from '@/pages/results';
import Leaderboard from '@/pages/leaderboard';
import Instructor from '@/pages/instructor';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/"><WindowGate><Overview /></WindowGate></Route>
        <Route path="/activity"><WindowGate><Activity /></WindowGate></Route>
        <Route path="/results"><WindowGate><Results /></WindowGate></Route>
        <Route path="/leaderboard"><WindowGate><Leaderboard /></WindowGate></Route>
        <Route path="/instructor" component={Instructor} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
